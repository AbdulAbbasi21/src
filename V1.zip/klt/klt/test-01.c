#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MATRIX_SIZE 150

// Function declarations
void matrix_addition(int **A, int **B, int **C, int size);
void matrix_multiplication(int **A, int **B, int **C, int size);
void matrix_transpose(int **A, int **T, int size);
int matrix_trace(int **A, int size);
void initialize_matrix(int **A, int size);
void print_matrix(int **A, int size);
void perform_operations(int **A, int **B, int **C, int **T, int size);

int main() {
    int size = MATRIX_SIZE;
    
    // Dynamic memory allocation for matrices
    int **A = (int **)malloc(size * sizeof(int *));
    int **B = (int **)malloc(size * sizeof(int *));
    int **C = (int **)malloc(size * sizeof(int *));
    int **T = (int **)malloc(size * sizeof(int *));
    for (int i = 0; i < size; i++) {
        A[i] = (int *)malloc(size * sizeof(int));
        B[i] = (int *)malloc(size * sizeof(int));
        C[i] = (int *)malloc(size * sizeof(int));
        T[i] = (int *)malloc(size * sizeof(int));
    }
    
    srand(time(NULL));
    initialize_matrix(A, size);
    initialize_matrix(B, size);
    
    perform_operations(A, B, C, T, size);
    
    // Free allocated memory
    for (int i = 0; i < size; i++) {
        free(A[i]);
        free(B[i]);
        free(C[i]);
        free(T[i]);
    }
    free(A);
    free(B);
    free(C);
    free(T);
    
    return 0;
}

void perform_operations(int **A, int **B, int **C, int **T, int size) {
    matrix_addition(A, B, C, size);
    matrix_multiplication(A, B, C, size);
    matrix_transpose(A, T, size);
    int trace = matrix_trace(A, size);
    printf("Trace of matrix A: %d\n", trace);
}

void matrix_addition(int **A, int **B, int **C, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            C[i][j] = A[i][j] + B[i][j];
        }
    }
}

void matrix_multiplication(int **A, int **B, int **C, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            C[i][j] = 0;
            for (int k = 0; k < size; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

void matrix_transpose(int **A, int **T, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            T[j][i] = A[i][j];
        }
    }
}

int matrix_trace(int **A, int size) {
    int trace = 0;
    for (int i = 0; i < size; i++) {
        trace += A[i][i];
    }
    return trace;
}

void initialize_matrix(int **A, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            A[i][j] = rand() % 100;
        }
    }
}
