#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ARRAY_SIZE 10000 // Increased array size

// Function declarations
long factorial(int n);
int fibonacci(int n);
void bubble_sort(int arr[], int n);
int find_max(int arr[], int n);

int main() {
    int num = 10;
    int n = ARRAY_SIZE;
    int *arr = (int *)malloc(n * sizeof(int));
    if (arr == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return 1;
    }

    // Initialize array with random values
    srand(time(NULL));
    for (int i = 0; i < n; i++) {
        arr[i] = rand() % 10000;
    }

    // Call functions to generate profiling data
    printf("Factorial of %d is %ld\n", num, factorial(num));
    printf("Fibonacci of %d is %d\n", num, fibonacci(num));
    
    bubble_sort(arr, n);
    printf("Sorted array: ");
    for (int i = 0; i < 10; i++) { // Print only first 10 elements to reduce output
        printf("%d ", arr[i]);
    }
    printf("...\n");
    
    printf("Maximum value in array: %d\n", find_max(arr, n));
    
    free(arr); // Free dynamically allocated memory
    return 0;
}

// Function to compute factorial (iterative with extra computations)
long factorial(int n) {
    long result = 1;
    for (int i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}

// Function to compute nth Fibonacci number (iterative with extra loops)
int fibonacci(int n) {
    if (n <= 0) return 0;
    if (n == 1) return 1;
    int a = 0, b = 1, c;
    for (int i = 2; i <= n; i++) {
        c = a + b;
        a = b;
        b = c;
    }
    return b;
}

// Function to sort an array using Bubble Sort
void bubble_sort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

// Function to find the maximum value in an array
int find_max(int arr[], int n) {
    int max = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
}
