#include<stdio.h>

void new_func1(void)
{
    printf("\n Inside new_func1()\n");
    int i = 0;

    for(;i<0xffffffe;i++);

    return;
}

void func1(void)
{
    printf("\n Inside func1 \n");
    int i = 0;

    for(;i<0xfffffff;i++);
    new_func1();
    new_func1();
    new_func1();

    return;
}

static void func2(void)
{
    printf("\n Inside func2 \n");
    int i = 0;

    for(;i<0x1fffffff;i++);
    return;
}

int main(void)
{
    printf("\n Inside main()\n");
    int i = 0;

    for(;i<0xfffff;i++);
    func1();
    func2();

    return 0;
}
