/*********************************************************************
 * convolve.c
 *********************************************************************/

/* Standard includes */
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <sys/time.h>   /* FOR gettimeofday */

/* Our includes */
#include "base.h"
#include "error.h"
#include "convolve.h"
#include "klt_util.h"

#define MAX_KERNEL_WIDTH 	71

typedef struct  {
  int width;
  float data[MAX_KERNEL_WIDTH];
}  ConvolutionKernel;

/* Kernels */
static ConvolutionKernel gauss_kernel;
static ConvolutionKernel gaussderiv_kernel;
static float sigma_last = -10.0;

/*********************************************************************
 * TIMING UTILITIES
 *********************************************************************/
typedef struct {
    struct timeval start;
    struct timeval end;
} Timer;

static void startTimer(Timer *t) {
    gettimeofday(&t->start, NULL);
}

static void stopTimer(Timer *t) {
    gettimeofday(&t->end, NULL);
}

static double getElapsedTime(Timer *t) {
    return (t->end.tv_sec - t->start.tv_sec) + 
           (t->end.tv_usec - t->start.tv_usec) / 1000000.0;
}

/*********************************************************************
 * _KLTToFloatImage
 */

void _KLTToFloatImage(
  KLT_PixelType *img,
  int ncols, int nrows,
  _KLT_FloatImage floatimg)
{
  KLT_PixelType *ptrend = img + ncols*nrows;
  float *ptrout = floatimg->data;

  assert(floatimg->ncols >= ncols);
  assert(floatimg->nrows >= nrows);

  floatimg->ncols = ncols;
  floatimg->nrows = nrows;

  while (img < ptrend)  *ptrout++ = (float) *img++;
}

/*********************************************************************
 * _computeKernels
 */

static void _computeKernels(
  float sigma,
  ConvolutionKernel *gauss,
  ConvolutionKernel *gaussderiv)
{
  const float factor = 0.01f;
  int i;

  assert(MAX_KERNEL_WIDTH % 2 == 1);
  assert(sigma >= 0.0);

  {
    const int hw = MAX_KERNEL_WIDTH / 2;
    float max_gauss = 1.0f, max_gaussderiv = (float) (sigma*exp(-0.5f));
	
    for (i = -hw ; i <= hw ; i++)  {
      gauss->data[i+hw]      = (float) exp(-i*i / (2*sigma*sigma));
      gaussderiv->data[i+hw] = -i * gauss->data[i+hw];
    }

    gauss->width = MAX_KERNEL_WIDTH;
    for (i = -hw ; fabs(gauss->data[i+hw] / max_gauss) < factor ; 
         i++, gauss->width -= 2);
    gaussderiv->width = MAX_KERNEL_WIDTH;
    for (i = -hw ; fabs(gaussderiv->data[i+hw] / max_gaussderiv) < factor ; 
         i++, gaussderiv->width -= 2);
    if (gauss->width == MAX_KERNEL_WIDTH || 
        gaussderiv->width == MAX_KERNEL_WIDTH)
      KLTError("(_computeKernels) MAX_KERNEL_WIDTH %d is too small for "
               "a sigma of %f", MAX_KERNEL_WIDTH, sigma);
  }

  for (i = 0 ; i < gauss->width ; i++)
    gauss->data[i] = gauss->data[i+(MAX_KERNEL_WIDTH-gauss->width)/2];
  for (i = 0 ; i < gaussderiv->width ; i++)
    gaussderiv->data[i] = gaussderiv->data[i+(MAX_KERNEL_WIDTH-gaussderiv->width)/2];

  {
    const int hw = gaussderiv->width / 2;
    float den;
			
    den = 0.0;
    for (i = 0 ; i < gauss->width ; i++)  den += gauss->data[i];
    for (i = 0 ; i < gauss->width ; i++)  gauss->data[i] /= den;
    den = 0.0;
    for (i = -hw ; i <= hw ; i++)  den -= i*gaussderiv->data[i+hw];
    for (i = -hw ; i <= hw ; i++)  gaussderiv->data[i+hw] /= den;
  }

  sigma_last = sigma;
}

/*********************************************************************
 * _KLTGetKernelWidths
 */

void _KLTGetKernelWidths(
  float sigma,
  int *gauss_width,
  int *gaussderiv_width)
{
  _computeKernels(sigma, &gauss_kernel, &gaussderiv_kernel);
  *gauss_width = gauss_kernel.width;
  *gaussderiv_width = gaussderiv_kernel.width;
}

/*********************************************************************
 * _convolveImageHoriz - GPU OPTIMIZED
 *********************************************************************/

static void _convolveImageHoriz(
  _KLT_FloatImage imgin,
  ConvolutionKernel kernel,  /* NOTE: ConvolutionKernel NOT KLT_ConvKernel */
  _KLT_FloatImage imgout)
{
  float *ptrrow = imgin->data;
  float *ptrout = imgout->data;
  float sum;
  int radius = kernel.width / 2;  /* NOTE: kernel.width NOT kernel->width */
  int ncols = imgin->ncols, nrows = imgin->nrows;
  int i, j, k;
  
  Timer timer;
  startTimer(&timer);

  /* Kernel width must be odd */
  assert(kernel.width % 2 == 1);
  /* Must read from and write to different images */
  assert(imgin != imgout);
  /* Output image must be large enough to hold result */
  assert(imgout->ncols >= imgin->ncols);
  assert(imgout->nrows >= imgin->nrows);

#ifdef GPU_ACCEL
  /* ========== GPU VERSION ========== */
  #pragma acc data copyin(ptrrow[0:ncols*nrows], \
                          kernel.data[0:kernel.width]) \
                   copyout(ptrout[0:ncols*nrows])
  {
    #pragma acc parallel loop gang vector
    for (j = 0; j < nrows; j++) {
      
      #pragma acc loop vector
      for (i = 0; i < ncols; i++) {
        sum = 0.0;
        
        if (i < radius || i >= ncols - radius) {
          /* Zero border pixels */
          ptrout[j*ncols + i] = 0.0;
        } else {
          /* Convolve middle columns with kernel */
          #pragma acc loop seq
          for (k = 0; k < kernel.width; k++) {
            sum += ptrrow[j*ncols + (i - radius + k)] * kernel.data[k];
          }
          ptrout[j*ncols + i] = sum;
        }
      }
    }
  }
#else
  /* ========== CPU VERSION (ORIGINAL) ========== */
  for (j = 0 ; j < nrows ; j++) {
    /* Zero leftmost columns */
    for (i = 0 ; i < radius ; i++)
      *ptrout++ = 0.0;
    
    /* Convolve middle columns with kernel */
    for ( ; i < ncols - radius ; i++) {
      float *ppp = ptrrow + i - radius;
      sum = 0.0;
      for (k = kernel.width-1 ; k >= 0 ; k--)
        sum += *ppp++ * kernel.data[k];
      *ptrout++ = sum;
    }
    
    /* Zero rightmost columns */
    for ( ; i < ncols ; i++)
      *ptrout++ = 0.0;
    
    ptrrow += ncols;
  }
#endif

  stopTimer(&timer);
  
#ifdef GPU_ACCEL
  printf("[GPU] _convolveImageHoriz: %.6f seconds\n", getElapsedTime(&timer));
#else
  printf("[CPU] _convolveImageHoriz: %.6f seconds\n", getElapsedTime(&timer));
#endif
}

/*********************************************************************
 * _convolveImageVert - GPU OPTIMIZED
 *********************************************************************/

static void _convolveImageVert(
  _KLT_FloatImage imgin,
  ConvolutionKernel kernel,  /* NOTE: ConvolutionKernel NOT KLT_ConvKernel */
  _KLT_FloatImage imgout)
{
  float *ptrcol = imgin->data;
  float *ptrout = imgout->data;
  float sum;
  int radius = kernel.width / 2;  /* NOTE: kernel.width NOT kernel->width */
  int ncols = imgin->ncols, nrows = imgin->nrows;
  int i, j, k;
  
  Timer timer;
  startTimer(&timer);

  /* Kernel width must be odd */
  assert(kernel.width % 2 == 1);
  /* Must read from and write to different images */
  assert(imgin != imgout);
  /* Output image must be large enough to hold result */
  assert(imgout->ncols >= imgin->ncols);
  assert(imgout->nrows >= imgin->nrows);

#ifdef GPU_ACCEL
  /* ========== GPU VERSION ========== */
  #pragma acc data copyin(ptrcol[0:ncols*nrows], \
                          kernel.data[0:kernel.width]) \
                   copyout(ptrout[0:ncols*nrows])
  {
    #pragma acc parallel loop collapse(2) gang vector
    for (i = 0; i < ncols; i++) {
      for (j = 0; j < nrows; j++) {
        sum = 0.0;
        
        if (j < radius || j >= nrows - radius) {
          /* Zero border pixels */
          ptrout[j*ncols + i] = 0.0;
        } else {
          /* Convolve middle rows with kernel */
          #pragma acc loop seq
          for (k = 0; k < kernel.width; k++) {
            sum += ptrcol[(j - radius + k)*ncols + i] * kernel.data[k];
          }
          ptrout[j*ncols + i] = sum;
        }
      }
    }
  }
#else
  /* ========== CPU VERSION (ORIGINAL) ========== */
  for (i = 0 ; i < ncols ; i++) {
    /* Zero topmost rows */
    for (j = 0 ; j < radius ; j++) {
      *ptrout = 0.0;
      ptrout += ncols;
    }
    
    /* Convolve middle rows with kernel */
    for ( ; j < nrows - radius ; j++) {
      float *ppp = ptrcol + ncols * (j - radius);
      sum = 0.0;
      for (k = kernel.width-1 ; k >= 0 ; k--) {
        sum += *ppp * kernel.data[k];
        ppp += ncols;
      }
      *ptrout = sum;
      ptrout += ncols;
    }
    
    /* Zero bottommost rows */
    for ( ; j < nrows ; j++) {
      *ptrout = 0.0;
      ptrout += ncols;
    }
    
    ptrcol++;
    ptrout -= nrows * ncols - 1;
  }
#endif

  stopTimer(&timer);
  
#ifdef GPU_ACCEL
  printf("[GPU] _convolveImageVert: %.6f seconds\n", getElapsedTime(&timer));
#else
  printf("[CPU] _convolveImageVert: %.6f seconds\n", getElapsedTime(&timer));
#endif
}

/*********************************************************************
 * _convolveSeparate
 *********************************************************************/

static void _convolveSeparate(
  _KLT_FloatImage imgin,
  ConvolutionKernel horiz_kernel,
  ConvolutionKernel vert_kernel,
  _KLT_FloatImage imgout)
{
  _KLT_FloatImage tmpimg;
  tmpimg = _KLTCreateFloatImage(imgin->ncols, imgin->nrows);
  
  _convolveImageHoriz(imgin, horiz_kernel, tmpimg);
  _convolveImageVert(tmpimg, vert_kernel, imgout);

  _KLTFreeFloatImage(tmpimg);
}

/*********************************************************************
 * _KLTComputeGradients
 *********************************************************************/

void _KLTComputeGradients(
  _KLT_FloatImage img,
  float sigma,
  _KLT_FloatImage gradx,
  _KLT_FloatImage grady)
{
  assert(gradx->ncols >= img->ncols);
  assert(gradx->nrows >= img->nrows);
  assert(grady->ncols >= img->ncols);
  assert(grady->nrows >= img->nrows);

  if (fabs(sigma - sigma_last) > 0.05)
    _computeKernels(sigma, &gauss_kernel, &gaussderiv_kernel);
	
  _convolveSeparate(img, gaussderiv_kernel, gauss_kernel, gradx);
  _convolveSeparate(img, gauss_kernel, gaussderiv_kernel, grady);
}

/*********************************************************************
 * _KLTComputeSmoothedImage
 *********************************************************************/

void _KLTComputeSmoothedImage(
  _KLT_FloatImage img,
  float sigma,
  _KLT_FloatImage smooth)
{
  assert(smooth->ncols >= img->ncols);
  assert(smooth->nrows >= img->nrows);

  if (fabs(sigma - sigma_last) > 0.05)
    _computeKernels(sigma, &gauss_kernel, &gaussderiv_kernel);

  _convolveSeparate(img, gauss_kernel, gauss_kernel, smooth);
}